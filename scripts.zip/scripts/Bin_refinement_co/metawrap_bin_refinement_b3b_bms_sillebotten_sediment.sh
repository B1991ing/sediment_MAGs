#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N metawrap_bin_refinement_b3b_bms_sillebotten_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/metawrap_bin_refinement_b3b_bms_sillebotten_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/metawrap_bin_refinement_b3b_bms_sillebotten_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=30:fatnode
### Memory
#PBS -l mem=1500gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=240:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load metawrap-mg/1.3.2

###Bins from #MetaBinner & SemiBin were used as the input of metawrap_bin_refinement_b3b_bms_sillebotten_sediment
#/home/projects/env_10000/people/binson/MTB/errfiles/metawrap_bin_refinement_b3b_bms_sillebotten_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/metawrap_bin_refinement_b3b_bms_sillebotten_sediment.log
#4:54:19, jobid 37459628, 26.8.2022 
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=30:fatnode,mem=1500gb,walltime=240:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/metawrap_bin_refinement_b3b_bms_sillebotten_sediment.sh
binning_dir=/home/projects/env_10000/people/binson/MTB/binning/
binny_bins=${binning_dir}binny_sillebotten_sediment/sillebotten_sediment_output/bins
semibin_bins=${binning_dir}semibin_sillebotten_sediment/output/output_bins
metabinner_bins=${binning_dir}metabinner_sillebotten_sediment/output/metabinner_res/ensemble_res/greedy_cont_weight_3_mincomp_50.0_maxcont_15.0_bins/ensemble_3logtrans/addrefined2and3comps/greedy_cont_weight_3_mincomp_50.0_maxcont_15.0_bins

bin_refinement_b3b_sillebotten_sediment=${binning_dir}bin_refinement_b3b_bms_sillebotten_sediment/
mkdir -p ${bin_refinement_b3b_sillebotten_sediment}
metawrap bin_refinement -o ${bin_refinement_b3b_sillebotten_sediment} -A ${metabinner_bins} -B ${semibin_bins} -C ${binny_bins} -t 30 -c 50 -x 10

qstat -f -1 $PBS_JOBID