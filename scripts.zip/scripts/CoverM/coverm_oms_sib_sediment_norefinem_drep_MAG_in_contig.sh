#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=600gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=00:6:00:00
###in the qsub script will cause running the job 9 times with not more than 4 actives jobs at any given time as default
###PBS -t 1-16%8

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load gcc/5.4.0 #CoverM
module load dashing/0.4.0 #CoverM
module load fastani/1.33 #CoverM
module load samtools/1.14 #CoverM
module load minimap2/2.24r1122 #CoverM
module load bwa-mem2/2.2.1 #CoverM
module load coverm/0.6.1 #CoverM

###Bins from the 3 best binners were selected for the next metaWRAP bin refinement.
#/home/projects/env_10000/people/binson/MTB/errfiles/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig.err
#/home/projects/env_10000/people/binson/MTB/logfiles/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig.log
#00:29:24, jobid 39338604, 17.2.2023
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=600gb,walltime=00:6:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig.sh
contig1=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_1/1_contigs.fasta
contig2=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_2/2_contigs.fasta
contig3=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_3/3_contigs.fasta
contig4=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_4/4_contigs.fasta
contig5=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_5/5_contigs.fasta
contig6=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_6/6_contigs.fasta
contig7=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_7/7_contigs.fasta
contig8=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_8/8_contigs.fasta
contig9=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_9/9_contigs.fasta
contig10=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_10/10_contigs.fasta
contig11=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_11/11_contigs.fasta
contig12=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_12/12_contigs.fasta
contig13=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_13/13_contigs.fasta
contig14=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_14/14_contigs.fasta
contig15=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_15/15_contigs.fasta
contig16=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/contig_16/16_contigs.fasta

genomes_dir=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/dereplicated_genomes/
out_dir=/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem_drep_MAG_in_contig/
mkdir -p ${out_dir}
out_tsv=${out_dir}relative_abundance.tsv

coverm genome -m relative_abundance --single ${contig1} ${contig2} ${contig3} ${contig4} ${contig5} ${contig6} ${contig7} ${contig8} ${contig9} ${contig10} ${contig11} ${contig12} ${contig13} ${contig14} ${contig15} ${contig16} --genome-fasta-extension fasta --genome-fasta-directory ${genomes_dir} -o ${out_tsv} --min-read-percent-identity 0.95 --min-read-aligned-percent 0.70 --threads 20 

#to calculate the mean of the relative proportion of mapped reads in each sample
#awk '{for(i=2;i<=NF;++i) printf $i "\t";printf "\n"}' relative_abundance.tsv | sed -n '2p' | awk '{for(i = 1; i <= NF; i++) sum += $i; print sum/NF}'
