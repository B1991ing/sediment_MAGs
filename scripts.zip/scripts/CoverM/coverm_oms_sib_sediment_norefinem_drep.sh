#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N coverm_oms_sib_sediment_norefinem_drep
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/coverm_oms_sib_sediment_norefinem_drep.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/coverm_oms_sib_sediment_norefinem_drep.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=600gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=00:12:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load gcc/5.4.0 #CoverM
module load dashing/0.4.0 #CoverM
module load fastani/1.33 #CoverM
module load samtools/1.14 #CoverM
module load minimap2/2.24r1122 #CoverM
module load bwa-mem2/2.2.1 #CoverM
module load coverm/0.6.1 #CoverM

###Bins from the 3 best binners were selected for the next metaWRAP bin refinement.
#/home/projects/env_10000/people/binson/MTB/errfiles/coverm_oms_sib_sediment_norefinem_drep.err
#/home/projects/env_10000/people/binson/MTB/logfiles/coverm_oms_sib_sediment_norefinem_drep.log
#, jobid , 28.12.2022
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=600gb,walltime=00:12:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/coverm_oms_sib_sediment_norefinem_drep.sh
d1=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/

genomes_dir=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/dereplicated_genomes/
out_dir=/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/
mkdir -p ${out_dir}
out_tsv=${out_dir}relative_abundance.tsv
cd ${d1}
#rename "fa" "fasta" *
#rename "fna" "fasta" *
#rename "fastasta" "fasta" *
coverm genome -m relative_abundance --coupled 1/1_1.fq.gz 1/1_2.fq.gz 2/2_1.fq.gz 2/2_2.fq.gz 3/3_1.fq.gz 3/3_2.fq.gz 4/4_1.fq.gz 4/4_2.fq.gz 5/5_1.fq.gz 5/5_2.fq.gz 6/6_1.fq.gz 6/6_2.fq.gz 7/7_1.fq.gz 7/7_2.fq.gz 8/8_1.fq.gz 8/8_2.fq.gz 9/9_1.fq.gz 9/9_2.fq.gz 10/10_1.fq.gz 10/10_2.fq.gz 11/11_1.fq.gz 11/11_2.fq.gz 12/12_1.fq.gz 12/12_2.fq.gz 13/13_1.fq.gz 13/13_2.fq.gz 14/14_1.fq.gz 14/14_2.fq.gz 15/15_1.fq.gz 15/15_2.fq.gz 16/16_1.fq.gz 16/16_2.fq.gz --genome-fasta-extension fasta --genome-fasta-directory ${genomes_dir} -o ${out_tsv} --min-read-percent-identity 0.95 --min-read-aligned-percent 0.70 --threads 20 
