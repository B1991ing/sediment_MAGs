#!/bin/sh   
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N megahit_sillebotten_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/megahit_sillebotten_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/megahit_sillebotten_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=30:fatnode
### Memory
#PBS -l mem=1500gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load idba/1.1.1 
module load megahit/1.2.9

#merge 1.fastq and 2.fastq and change to fasta format
#3:07:00 (jobid 36497477, 12.7.2022)
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:thinnode,walltime=24:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/megahit_sillebotten_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/merge_sillebotten_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/merge_sillebotten_sediment.log
#sillebotten sediment - 1-8
# d1=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/
# d3=/home/projects/env_10000/people/binson/MTB/sillebotten_sediment_fq
# mkdir -p ${d3}
# cat ${d1}1/1_1.fastq ${d1}2/2_1.fastq ${d1}3/3_1.fastq ${d1}4/4_1.fastq ${d1}5/5_1.fastq ${d1}6/6_1.fastq ${d1}7/7_1.fastq ${d1}8/8_1.fastq > ${d3}/sillebotten_sediment_1.fastq
# cat ${d1}1/1_2.fastq ${d1}2/2_2.fastq ${d1}3/3_2.fastq ${d1}4/4_2.fastq ${d1}5/5_2.fastq ${d1}6/6_2.fastq ${d1}7/7_2.fastq ${d1}8/8_2.fastq > ${d3}/sillebotten_sediment_2.fastq
# fq2fa --merge --filter ${d3}/sillebotten_sediment_1.fastq ${d3}/sillebotten_sediment_2.fastq ${d3}/sillebotten_sediment.fa 

#5:21:28:44 (jobid 50052217, 31.5.2024)
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=30:fatnode,mem=1500gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/megahit_sillebotten_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/megahit_sillebotten_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/megahit_sillebotten_sediment.log
#-o/--out-dir: '-o' will say exit with an error if the output directory already exists
#!!!!!!Use options before specifying the input files, not afterwards.
se_fa=/home/projects/env_10000/people/binson/MTB/sillebotten_sediment_fq/sillebotten_sediment.fa
out_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/
megahit_out=${out_dir}megahit_sillebotten_sediment/
/services/tools/megahit/1.2.9/bin/megahit --min-contig-len 1000 --k-min 27 --k-max 127 --k-step 10 --kmin-1pass --min-count 2 --no-mercy -t 30 -m 0.8 --mem-flag 2 -r ${se_fa} --out-dir ${megahit_out}
#The contigs can be found final.contigs.fa in the output directory.