#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N semibin_sillebotten_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/semibin_sillebotten_sediment.err_1_8
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/semibin_sillebotten_sediment.log_1_8
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=1200gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load miniconda3/4.12.0
module load snakemake/7.8.2
module load samtools/1.14
module load bwa/0.7.17
module load sambamba/0.8.0 

module load mmseqs2/release_12-113e3 #semibin
module load hmmer/3.3.2 #dRep and semibin
module load prodigal/2.6.3 #dRep and semibin
module load perl/5.30.2 #prereq for fraggenescan/1.31
module load fraggenescan/1.31 #semibin 
module load semibin/0.7.0

#23:40:14 (jobid 36666522, 24.7.2022)
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=40:thinnode,walltime=96:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/semibin_sillebotten_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/semibin_bam_sillebotten_sediment.err-1,2,3,4,5,6,7,8
#/home/projects/env_10000/people/binson/MTB/logfiles/semibin_bam_sillebotten_sediment.log-1,2,3,4,5,6,7,8
# semibin_sillebotten_sediment_dir=/home/projects/env_10000/people/binson/MTB/binning/semibin_sillebotten_sediment/
# mkdir -p ${semibin_sillebotten_sediment_dir}
# megahit_sillebotten_sediment_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_sillebotten_sediment/
# contig=${megahit_sillebotten_sediment_dir}final.contigs.fa

# bwa index ${contig} 

#map reads from each sample to bin_all.fa (use the trimmed fastq files!!!, not the original ones)
# for n in {1,2,3,4,5,6,7,8}
# do
#     fastq_dir=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/${n}/
#     cd ${fastq_dir}
#     f1=${n}_1.fastq
#     f2=${f1%%1.fastq}"2.fastq"
#     bwa mem -t 40 -M ${contig} $f1 $f2 | samtools view -Sb - > ${semibin_sillebotten_sediment_dir}${f1%%_1.fastq}_raw.bam

#     cd ${semibin_sillebotten_sediment_dir}
#     rawbam=${n}_raw.bam
#     sambamba view -t 40 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" ${rawbam} -o ${rawbam%%.bam}_unique.bam

#     cd ${semibin_sillebotten_sediment_dir}
#     uniquebam=${n}_raw_unique.bam
#     samtools view -h ${uniquebam} | samtools view -Su -q30 - | samtools sort -O BAM -o ${uniquebam%%.bam}_sort.bam
#     samtools index ${uniquebam%%.bam}_sort.bam   
# done


#SemiBin - TRY FAT NODE
#7:16:02 (jobid 36685017, 26.7.2022)
# Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=1200gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/semibin_sillebotten_sediment.sh
# /home/projects/env_10000/people/binson/MTB/errfiles/semibin_sillebotten_sediment.err_1_8
# /home/projects/env_10000/people/binson/MTB/logfiles/semibin_sillebotten_sediment.log_1_8
semibin_sillebotten_sediment_dir=/home/projects/env_10000/people/binson/MTB/binning/semibin_sillebotten_sediment/
megahit_sillebotten_sediment_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_sillebotten_sediment/
contig=${megahit_sillebotten_sediment_dir}final.contigs.fa

bam1=${semibin_sillebotten_sediment_dir}1_raw_unique_sort.bam
bam2=${semibin_sillebotten_sediment_dir}2_raw_unique_sort.bam
bam3=${semibin_sillebotten_sediment_dir}3_raw_unique_sort.bam
bam4=${semibin_sillebotten_sediment_dir}4_raw_unique_sort.bam
bam5=${semibin_sillebotten_sediment_dir}5_raw_unique_sort.bam
bam6=${semibin_sillebotten_sediment_dir}6_raw_unique_sort.bam
bam7=${semibin_sillebotten_sediment_dir}7_raw_unique_sort.bam
bam8=${semibin_sillebotten_sediment_dir}8_raw_unique_sort.bam
output=${semibin_sillebotten_sediment_dir}output
#GTDB database was downloaded before
refdb_dir=/home/projects/env_10000/people/binson/Current_pipeline/binning/semibin/mmseqs2-GTDB
#next time, use --threads
SemiBin single_easy_bin -r ${refdb_dir} -i ${contig} -b ${bam1} ${bam2} ${bam3} ${bam4} ${bam5} ${bam6} ${bam7} ${bam8} -o ${output} --threads 20
#The output includes the bins in the output_recluster_bins directory (including the bin.*.fa and recluster.*.fa).

qstat -f -1 $PBS_JOBID