#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N semibin_omstrup_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/semibin_bam_omstrup_sediment.err-9,10,11,12,13,14,15,16
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/semibin_bam_omstrup_sediment.log-9,10,11,12,13,14,15,16
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=1200gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load miniconda3/4.12.0
module load snakemake/7.8.2
module load samtools/1.14
module load bwa/0.7.17
module load sambamba/0.8.0 

module load mmseqs2/release_12-113e3 #semibin
module load hmmer/3.3.2 #dRep and semibin
module load prodigal/2.6.3 #dRep and semibin
module load perl/5.30.2 #prereq for fraggenescan/1.31
module load fraggenescan/1.31 #semibin 
module load semibin/0.7.0

# 1:00:32:48(jobid 36666521, 24.7.2022)
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=40:thinnode,walltime=96:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/semibin_omstrup_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/semibin_bam_omstrup_sediment.err-9,10,11,12,13,14,15,16
#/home/projects/env_10000/people/binson/MTB/logfiles/semibin_bam_omstrup_sediment.log-9,10,11,12,13,14,15,16
# semibin_omstrup_sediment_dir=/home/projects/env_10000/people/binson/MTB/binning/semibin_omstrup_sediment/
# mkdir -p ${semibin_omstrup_sediment_dir}
# megahit_omstrup_sediment_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_omstrup_sediment/
# contig=${megahit_omstrup_sediment_dir}final.contigs.fa

# bwa index ${contig} 

#map reads from each sample to bin_all.fa (use the trimmed fastq files!!!, not the original ones)
# for n in {9,10,11,12,13,14,15,16}
# do
#     fastq_dir=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/${n}/
#     cd ${fastq_dir}
#     f1=${n}_1.fastq
#     f2=${f1%%1.fastq}"2.fastq"
#     bwa mem -t 40 -M ${contig} $f1 $f2 | samtools view -Sb - > ${semibin_omstrup_sediment_dir}${f1%%_1.fastq}_raw.bam

#     cd ${semibin_omstrup_sediment_dir}
#     rawbam=${n}_raw.bam
#     sambamba view -t 40 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" ${rawbam} -o ${rawbam%%.bam}_unique.bam

#     cd ${semibin_omstrup_sediment_dir}
#     uniquebam=${n}_raw_unique.bam
#     samtools view -h ${uniquebam} | samtools view -Su -q30 - | samtools sort -O BAM -o ${uniquebam%%.bam}_sort.bam
#     samtools index ${uniquebam%%.bam}_sort.bam   
# done

#SemiBin - TRY FAT NODE
#8:12:38 (jobid 36675707, 25.7.2022)
# Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=1200gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/semibin_omstrup_sediment.sh
# /home/projects/env_10000/people/binson/MTB/errfiles/semibin_bam_omstrup_sediment.err-9,10,11,12,13,14,15,16
# /home/projects/env_10000/people/binson/MTB/logfiles/semibin_bam_omstrup_sediment.log-9,10,11,12,13,14,15,16
semibin_omstrup_sediment_dir=/home/projects/env_10000/people/binson/MTB/binning/semibin_omstrup_sediment/
megahit_omstrup_sediment_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_omstrup_sediment/
contig=${megahit_omstrup_sediment_dir}final.contigs.fa

bam9=${semibin_omstrup_sediment_dir}9_raw_unique_sort.bam
bam10=${semibin_omstrup_sediment_dir}10_raw_unique_sort.bam
bam11=${semibin_omstrup_sediment_dir}11_raw_unique_sort.bam
bam12=${semibin_omstrup_sediment_dir}12_raw_unique_sort.bam
bam13=${semibin_omstrup_sediment_dir}13_raw_unique_sort.bam
bam14=${semibin_omstrup_sediment_dir}14_raw_unique_sort.bam
bam15=${semibin_omstrup_sediment_dir}15_raw_unique_sort.bam
bam16=${semibin_omstrup_sediment_dir}16_raw_unique_sort.bam
output=${semibin_omstrup_sediment_dir}output
#GTDB database was downloaded before
refdb_dir=/home/projects/env_10000/people/binson/Current_pipeline/binning/semibin/mmseqs2-GTDB
#next time, use --threads
SemiBin single_easy_bin -r ${refdb_dir} -i ${contig} -b ${bam9} ${bam10} ${bam11} ${bam12} ${bam13} ${bam14} ${bam15} ${bam16} -o ${output} --threads 20
# The output includes the bins in the output_recluster_bins directory (including the bin.*.fa and recluster.*.fa).

qstat -f -1 $PBS_JOBID