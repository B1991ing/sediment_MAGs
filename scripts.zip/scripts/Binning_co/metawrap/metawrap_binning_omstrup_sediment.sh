#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N metawrap_binning_omstrup_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/metawrap_binning_omstrup_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/metawrap_binning_omstrup_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=30:fatnode
### Memory
#PBS -l mem=1500gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load metawrap-mg/1.3.2

#Binning MAGs using MetaBAT2 and MaxBin2 by metaWRAP
#6:14:42:11 (jobid 36642120, 20.7.2022)
#qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=30:fatnode,mem=1500gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/metawrap_binning_omstrup_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/metawrap_binning_omstrup_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/metawrap_binning_omstrup_sediment.log
metawrap_binning_out=/home/projects/env_10000/people/binson/MTB/binning/metawrap_binning_omstrup_sediment
mkdir -p ${metawrap_binning_out}
fastq_dir=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/
metawrap binning -a /home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_omstrup_sediment/final.contigs.fa -o ${metawrap_binning_out} -t 30 --metabat2 --maxbin2 ${fastq_dir}9/9_[1-2].fastq ${fastq_dir}10/10_[1-2].fastq ${fastq_dir}11/11_[1-2].fastq ${fastq_dir}12/12_[1-2].fastq ${fastq_dir}13/13_[1-2].fastq ${fastq_dir}14/14_[1-2].fastq ${fastq_dir}15/15_[1-2].fastq ${fastq_dir}16/16_[1-2].fastq
