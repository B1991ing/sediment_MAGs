#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N metadecoder_omstrup_sediment_megahit
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/metadecoder_omstrup_sediment_megahit.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/metadecoder_omstrup_sediment_megahit.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=40:thinnode
### Memory
###PBS -l mem=400gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load tools computerome_utils/2.0
module load anaconda3/2021.11 #metadecoder 1.0.13
module load samtools/1.14

#1:09:30:05 (jobid 36673787, 25.7.2022)
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=40:thinnode,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/metadecoder_omstrup_sediment_megahit.sh
#error file: /home/projects/env_10000/people/binson/MTB/errfiles/metadecoder_omstrup_sediment_megahit.err
#log file: /home/projects/env_10000/people/binson/MTB/logfiles/metadecoder_omstrup_sediment_megahit.log
# Step 1, convert all BAM files to SAM files using Samtools:
dir1=/home/projects/env_10000/people/binson/MTB/binning/metadecoder_omstrup_sediment_megahit/
mkdir ${dir1}
dir=/home/projects/env_10000/people/binson/MTB/binning/semibin_omstrup_sediment/

for n in {9,10,11,12,13,14,15,16};
do
    SAM=${dir}${n}_raw_unique_sort.sam
    BAM=${dir}${n}_raw_unique_sort.bam
    samtools view -@ 10 -h -o ${SAM} ${BAM}
done

# Step 2, get the coverage file:
SAM=${dir}*_raw_unique_sort.sam
COVERAGE=${dir1}omstrup_sediment_METADECODER.COVERAGE
metadecoder coverage -s ${SAM} -o ${COVERAGE}

# Step3, get the seed file:
megahit_omstrup_sediment_dir=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_omstrup_sediment/
ASSEMBLY=${megahit_omstrup_sediment_dir}final.contigs.fa
SEED=${dir1}omstrup_sediment_METADECODER.SEED
metadecoder seed -f ${ASSEMBLY} -o ${SEED}

# Step4, run MetaDecoder for clustering contigs:
cd ${dir1}
SEED=omstrup_sediment_METADECODER.SEED
COVERAGE=omstrup_sediment_METADECODER.COVERAGE
METADECODER=omstrup_sediment.METADECODER
metadecoder cluster -f ${ASSEMBLY} -s ${SEED} -c ${COVERAGE} -o ${METADECODER}
