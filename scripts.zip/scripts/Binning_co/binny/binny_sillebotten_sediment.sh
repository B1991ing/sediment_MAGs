#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N binny_sillebotten_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/binny_sillebotten_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/binny_sillebotten_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=1000gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load miniconda3/4.12.0
module load snakemake/7.8.2
module load samtools/1.14
module load bwa/0.7.17
module load sambamba/0.8.0 
module load samtools/1.14
module load bwa/0.7.17
module load sambamba/0.8.0 

#21:49:21 (jobid 36675712, 25.7.2022)
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=1000gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/binny_sillebotten_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/binny_sillebotten_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/binny_sillebotten_sediment.log
#use the bam file in the dir - /home/projects/env_10000/people/binson/MTB/binning/semibin_sillebotten_sediment/
contig_sillebotten_sediment=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_sillebotten_sediment/final.contigs.fa
contig_sillebotten_sediment_idonly=/home/projects/env_10000/people/binson/MTB/assemble/megahit/megahit_sillebotten_sediment/final.contigs.idonly.fa
sed -e "s/ .*//g" ${contig_sillebotten_sediment} > ${contig_sillebotten_sediment_idonly}

binny_sillebotten_sediment_dir=/home/projects/env_10000/people/binson/MTB/binning/binny_sillebotten_sediment/
mkdir -p ${binny_sillebotten_sediment_dir}
mv /home/projects/env_10000/people/binson/MTB/binning/config_sillebotten_sediment.yaml ${binny_sillebotten_sediment_dir}

configfile=${binny_sillebotten_sediment_dir}config_sillebotten_sediment.yaml
snakemake -c 20 -s /home/projects/env_10000/people/binson/binny/Snakefile --configfile ${configfile} --use-conda --conda-prefix /home/projects/env_10000/people/binson/binny/conda