#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N drep_vamb_binny_omstrup_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/drep_vamb_binny_omstrup_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/drep_vamb_binny_omstrup_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=32:fatnode
### Memory
#PBS -l mem=800gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=240:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11 #drep
module load hmmer/3.3.2 #dRep and semibin
module load prodigal/2.6.3 #dRep and semibin 
module load pplacer/1.1.alpha19 #dRep
module load fastani/1.33 #dRep #CoverM
module load mash/2.3 #dRep
module load mummer/4.0.0beta2 #dRep
module load anicalculator/1 #dRep
module load centrifuge/1.0.4-beta #dRep

###dRep 99% ANI
#00:47:36, jobid 37459658, 26.8.2022
#Thinnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=32:fatnode,mem=800gb,walltime=240:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/drep_vamb_binny_omstrup_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/drep_vamb_binny_omstrup_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/drep_vamb_binny_omstrup_sediment.log
#Must check dRep dependencies: dRep bonus --check_dependencies work_directory
#dRep bonus --check_dependencies /home/projects/env_10000/people/binson/MTB/binning/vamb_25/vamb/bins/
vamb_bin_dir=/home/projects/env_10000/people/binson/MTB/binning/vamb_omstrup_sediment/vamb/bins/
outout_directory=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny/drep_vamb_binny_omstrup_sediment/
mkdir -p ${outout_directory}
GENOMES=${outout_directory}bins_vamb_binny_omstrup_sediment.txt
ls -R ${vamb_bin_dir}* > ${GENOMES}
for n in 9 10 11 12 13 14 15 16 ;
do
    binny_dir=/home/projects/env_10000/people/binson/MTB/binning/binny_${n}/${n}_output/bins/
    ls -R ${binny_dir}*.fasta >> ${GENOMES}
done
dRep dereplicate ${outout_directory} -g ${GENOMES} -p 32 -comp 50 -con 5 --debug
