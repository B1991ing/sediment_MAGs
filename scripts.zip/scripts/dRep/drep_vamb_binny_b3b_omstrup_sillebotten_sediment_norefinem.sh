#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=32:fatnode
### Memory
#PBS -l mem=640gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=240:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11 #drep
module load hmmer/3.3.2 #dRep and semibin
module load prodigal/2.6.3 #dRep and semibin 
module load pplacer/1.1.alpha19 #dRep
module load fastani/1.33 #dRep #CoverM
module load mash/2.3 #dRep
module load mummer/4.0.0beta2 #dRep
module load anicalculator/1 #dRep
module load centrifuge/1.0.4-beta #dRep

###dRep 99% ANI
#1:21:55, jobid 37779924, 4.10.2022
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=32:fatnode,mem=640gb,walltime=240:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem.err
#/home/projects/env_10000/people/binson/MTB/logfiles/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem.log
#Must check dRep dependencies: dRep bonus --check_dependencies work_directory
outout_directory=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/99/
mkdir -p ${outout_directory}
GENOMES=${outout_directory}vamb_binny_b3b.txt

#b3b - "omstrup_sediment"
for r in omstrup_sediment ;
do
    b3b_dir=/home/projects/env_10000/people/binson/MTB/binning/bin_refinement_b3b_bsm_${r}/metawrap_50_10_bins/
    #cd ${b3b_dir}    
    ls -R ${b3b_dir}* >> ${GENOMES} 
done

#vamb_binny - "omstrup_sediment"
vamb_binny=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny/
for r in omstrup_sediment ;
do
    vamb_binny_bins=${vamb_binny}drep_vamb_binny_${r}/dereplicated_genomes/
    ls -R ${vamb_binny_bins}* >> ${GENOMES}
done

#b3b - "sillebotten_sediment"
for r in sillebotten_sediment ;
do
    b3b_dir=/home/projects/env_10000/people/binson/MTB/binning/bin_refinement_b3b_bms_${r}/metawrap_50_10_bins/
    #cd ${b3b_dir}    
    ls -R ${b3b_dir}* >> ${GENOMES} 
done

#vamb_binny - "sillebotten_sediment"
vamb_binny=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny/
for r in sillebotten_sediment ;
do
    vamb_binny_bins=${vamb_binny}drep_vamb_binny_${r}/dereplicated_genomes/
    ls -R ${vamb_binny_bins}* >> ${GENOMES}
done

dRep dereplicate ${outout_directory} -g ${GENOMES} -p 32 -comp 50 -con 5 --debug

drep99_output_bin=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/99/dereplicated_genomes/
drep95_output_dir=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/
mkdir -p ${drep95_output_dir}
GENOMES=${drep95_output_dir}vamb_binny_b3b.txt
ls -R ${drep99_output_bin}* > ${GENOMES}
dRep dereplicate ${drep95_output_dir} -g ${GENOMES} -p 32 -sa 0.95 -comp 50 -con 5 --debug
