#!usr/bin/python
import ete3
#check ete3 version
# module load tools
# module load anaconda3/2021.11
# pip list
from ete3 import Tree

# Loads 3 independent trees
# t1 = Tree('(A,(B,C));')
# t2 = Tree('((D,E), (F,G));')
# print("Tree1:", t1)
# print("Tree1:", t2)
# and adds the two other trees as children.
# t1.add_child(t2)
# print("Tree1:", t1)

# Load a bacterial tree structure from a newick file.
tbac = Tree("/home/projects/env_10000/people/binson/MTB/gtdbtk/de_novo_wf/species_omstrup_sillebotten_sediment_norefinem/infer/labelremoved_gtdbtk.bac120.decorated.nwk")
print("tbac:", tbac)
tarc = Tree("/home/projects/env_10000/people/binson/MTB/gtdbtk/de_novo_wf/species_omstrup_sillebotten_sediment_norefinem_archaea/infer/intermediate_results/labelremoved_gtdbtk.ar53.unrooted.nwk")
print("tarc:", tarc)
t_bacarc_out = "/home/projects/env_10000/people/binson/MTB/gtdbtk/de_novo_wf/species_omstrup_sillebotten_sediment_norefinem/infer/labelremoved_gtdbtk.ar53.unrooted.bac120.decorated.nwk"
t_bacarc = tbac.add_child(tarc)
print("t_bacarc:", t_bacarc)
t_bacarc1 = t_bacarc.get_tree_root()
print(t_bacarc1)
# # We can also write into a file
t_bacarc1.write(format=1, outfile=t_bacarc_out)

# module load tools
# module load anaconda3/2021.11
# python /home/projects/env_10000/people/binson/scripts/MTBscripts/ete_MAG330_bacarc.py