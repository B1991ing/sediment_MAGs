#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N gtdbtk_species_sillebotten_sediment_norefinem
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/classify_wf_sillebotten_sediment_norefinem.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/classify_wf_sillebotten_sediment_norefinem.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=32:fatnode
### Memory
#PBS -l mem=1280gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=240:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11 #drep
module load gtdbtk/2.1.0 
module load pplacer/1.1.alpha19
module load fasttree/2.1.11 #gtdbtk de_novo_wf
module load mash/2.3 #gtdbtk de_novo_wf and dRep

##########################gtdbtk classify_wf##########################
#Classify Bins using gtdbtk (--pplacer_cpus used here) based on bins from dRep95_comp50_con5
# (jobid , 18.10.2022)
#/home/projects/env_10000/people/binson/MTB/errfiles/classify_wf_sillebotten_sediment_norefinem.err
#/home/projects/env_10000/people/binson/MTB/logfiles/classify_wf_sillebotten_sediment_norefinem.log
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=32:fatnode,mem=1280gb,walltime=240:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/gtdbtk_species_sillebotten_sediment_norefinem.sh

drep95_output_bin=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_sillebotten_sediment_norefinem/95/dereplicated_genomes/
drep95_output_dir=/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_sillebotten_sediment_norefinem/95/
sillebotten_sedimentfile_name=${drep95_output_dir}genomes_name.txt
sillebotten_sedimentfile_dir=${drep95_output_dir}genomes_dir.txt

#parameter1:
sillebotten_sedimentfile=${drep95_output_dir}genomesinfo.txt
cd ${drep95_output_bin}
for i in *;do echo ${i%.*};done > ${sillebotten_sedimentfile_name}
ls -R ${drep95_output_bin}* > ${sillebotten_sedimentfile_dir}
paste -d "\t" ${sillebotten_sedimentfile_dir} ${sillebotten_sedimentfile_name} > ${sillebotten_sedimentfile}

#parameter2:
output_dir=/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf_sillebotten_sediment_norefinem/
mkdir -p ${output_dir}

#rename "[class]" "" *
gtdbtk classify_wf --cpus 16 --pplacer_cpus 16 --batchfile ${sillebotten_sedimentfile} --out_dir ${output_dir}
