#!usr/bin/python
from email.headerregistry import Group
from telnetlib import PRAGMA_HEARTBEAT
from collections import Counter
from turtle import pen, title
from xml.etree.ElementTree import TreeBuilder
import pandas as pd
from pandas import Series,DataFrame
import os, re, csv
from itertools import chain

#MAG_quality, mam_domain
#To make the MAG_id has the same annotation order as the script - 
def MAG_quality(Widb_csv,MAG_cont_comp):
    df=pd.read_csv(Widb_csv,sep=",",header=0,engine='python')#,engine='python')
    #df["MAG"] = df.apply(lambda x: x['genome'][:-4], axis = 1)
    df["MAG"] = df.apply(lambda x: ".".join((x['genome'].split(".")[:-1])), axis = 1)
    #print(df['MAG'])
    #df["MAG_quality"] = df.apply(lambda x: x['completeness'], axis = 1) 
    
    #to remove "[class]" from the each MAG name
    df['MAG'] = df['MAG'].map(lambda x: x.replace("[class]", '') if "[class]" in x else x)  
    #print(df["MAG_taxa"])

    #to make a copy for outputing score completeness contamination strain_heterogeneity size N50 cluster taxonomy tax_confidence cluster_members closest_cluster_member furthest_cluster_member completeness_metric contamination_metric as columns of supplementary table
    df_out = df.copy()
    # print("df_out", df_out)

    MAGlist = df['MAG'].tolist()
    df.loc[((df.completeness >= 50) & (70 > df.completeness) & (df.contamination <= 5)), 'MAG_quality'] = 'LQ_com50-70'
    df.loc[((df.completeness >= 70) & (90 > df.completeness) & (df.contamination <= 5)), 'MAG_quality'] = 'MQ_com70-90'
    df.loc[((df.completeness >= 90) & (df.contamination <= 5)), 'MAG_quality'] = 'HQ_com90-100'
    MAG_quality_dict = df.set_index(['MAG'])['MAG_quality'].to_dict()
    #print(MAG_quality_dict)

    df.loc[((df.completeness >= 50) & (70 > df.completeness) & (df.contamination <= 5)), 'MAG_quality1'] = 'LQ'
    df.loc[((df.completeness >= 70) & (90 > df.completeness) & (df.contamination <= 5)), 'MAG_quality1'] = 'MQ'
    df.loc[((df.completeness >= 90) & (df.contamination <= 5)), 'MAG_quality1'] = 'HQ'
    MAG_quality_dict1 = df.set_index(['MAG'])['MAG_quality1'].to_dict()
    #print(MAG_quality_dict1)
    # print(df['MAG_quality1'].value_counts())
    df_4cols = df[["MAG","MAG_quality","completeness","contamination"]]  
    #print(df_4cols)
    df_4cols.to_csv(MAG_cont_comp, sep = "\t",index=False,header=True)
    # print("df_out", df_out)
    return MAGlist,MAG_quality_dict,MAG_quality_dict1,df_out
maginfo = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/data_tables/Widb.csv"
MAG_cont_comp = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/data_tables/MAG_cont_comp.tsv"
MAGlist,MAG_quality_dict,MAG_quality_dict1,df_out = MAG_quality(maginfo,MAG_cont_comp)  
# LQ    154
# MQ    135
# HQ     41



#4.6.2024 Tuesday
#to make input file for /Volumes/Extreme_SSD/sediment/Sediment_manuscript/microbiome/submission/contigMAG_uploading/MIMAG.sediment.6.0_bing.xlsx (NCBI)
maginfo_oms = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sediment_norefinem/95/data_tables/Widb.csv"
MAG_cont_comp_oms = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sediment_norefinem/95/data_tables/MAG_cont_comp_oms.tsv"
MAGlist_oms,MAG_quality_dict_oms,MAG_quality_dict1_oms,df_out = MAG_quality(maginfo_oms,MAG_cont_comp_oms)
biosample_oms = ["SAMN37286856","SAMN37286857","SAMN37286858","SAMN37286859","SAMN37286860","SAMN37286861","SAMN37286862","SAMN37286863"]
biosample_oms_str = ",".join(biosample_oms)
maginfo_sib = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_sillebotten_sediment_norefinem/95/data_tables/Widb.csv"
MAG_cont_comp_sib = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_sillebotten_sediment_norefinem/95/data_tables/MAG_cont_comp_sib.tsv"
MAGlist_sib,MAG_quality_dict_sib,MAG_quality_dict1_sib,df_out = MAG_quality(maginfo_sib,MAG_cont_comp_sib)  
biosample_sib = ["SAMN37286848","SAMN37286849","SAMN37286850","SAMN37286851","SAMN37286852","SAMN37286853","SAMN37286854","SAMN37286855"]
biosample_sib_str = ",".join(biosample_sib)

def mam_domain(dereplicated_genomes_dir):
    df_one_total = pd.DataFrame([], columns = ['qseqid', 'sseqid', 'qlen', 'slen', 'qstart', 'qend', 'qseq', 'sseq', 'length', 'pident', 'evalue', 'bitscore', "contig_gene", 'MAG_id', 'mam_id'])
    MAG_id_list = []  
    MAG_id_list1 = []
    MAG_mam_dict = {}
    MAG_contig_dict = {}
    for root, dirs, files in os.walk(dereplicated_genomes_dir):
        for name in files:
            if name.endswith(".dmnd.out"):
                fileroot = "/".join((root, name))
                split_fileroot = fileroot.split("/")
                MAG_id = "_".join((split_fileroot[-1]).split("_")[:-2])
                if MAG_id not in MAG_id_list:
                    MAG_id_list.append(MAG_id)          
    #print(MAG_id_list)
    return MAG_id_list
magfolder = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/dereplicated_genomes/"
MAG_id_list = mam_domain(magfolder)
#python /home/projects/env_10000/people/binson/scripts/MTBscripts/Omstrup_sillebotten_sediment_norefinem_mam_domain_selection_diamond.py
#print(MAG_id_list)

#delete three strings at the beginning
def taxa_name(dfcontact1, taxa, replace_str):
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a[3:] if len(a)>3 else a)
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a.replace(replace_str, '_'))
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a.replace(' ', '_'))
    return dfcontact1[taxa]

#The function - tsv_to_profile is to make two dicts - bin_taxa_dict and bin_POG_dict
def bin_SPS(a):
    df=pd.read_csv(a,sep="\t",comment="#",header=0)
    # print("df", df)
    # print("df.shape", df.shape)
    df_col2 = df[['user_genome', 'classification']]
    # print("df_col2", df_col2)
    # print("df_col2.shape", df_col2.shape)    
    dct6 = df_col2.set_index(['user_genome'])['classification'].to_dict()
    # print("dct6", dct6)

    df1 = pd.DataFrame(df['classification'].str.split(';').tolist(), columns=['Domain', "Phylum", 'Class', 'Order', 'Family', 'Genus', 'Species'])
    #print(df)
    df2 = df1[['Domain', "Phylum", 'Class', 'Order', 'Family', 'Genus', 'Species']]
    dfcontact = pd.concat([df["user_genome"],df2], axis=1)
    #print(dfcontact)

    dfcontact1 = dfcontact.copy()
    dfcontact1["Phylum"] = dfcontact1["Phylum"].map(lambda a : a[3:])

    dfcontact1['Class'] = taxa_name(dfcontact1, 'Class', 'c__')
    dfcontact1['Family'] = taxa_name(dfcontact1, 'Family', 'f__')
    dfcontact1['Order'] = taxa_name(dfcontact1, 'Order', 'o__')
    dfcontact1['Genus'] = taxa_name(dfcontact1, 'Genus', 'g__')
    dfcontact1['Species'] = taxa_name(dfcontact1, 'Species', 's__')
    dfcontact1['Species'] = dfcontact1['Species'].map(lambda a : a.replace('__', '_'))

    #Phylum_name + Species_name
    dfcontact1["POG"] = dfcontact1.apply(lambda x: x["Phylum"] + ";" + x["Order"] + ";" + str(x["Genus"]), axis = 1) 
    #for the lefse analysis
    dfcontact1["POG"] = dfcontact1["POG"].map(lambda x: x.replace("-","_"))   

    #Phylum_name + Class_name
    dfcontact1["Phylum_Class"] = dfcontact1.apply(lambda x: x["Phylum"] + ";" + str(x["Class"]), axis = 1) 
    #Phylum_name + Order_name
    dfcontact1["Phylum_Order"] = dfcontact1.apply(lambda x: x["Phylum"] + ";" + str(x["Order"]), axis = 1) 
    #Phylum_name + Family_name
    dfcontact1["Phylum_Family"] = dfcontact1.apply(lambda x: x["Phylum"] + ";" + str(x["Family"]), axis = 1) 
    #Phylum_name + Genus_name
    dfcontact1["Phylum_Genus"] = dfcontact1.apply(lambda x: x["Phylum"] + ";" + str(x["Genus"]), axis = 1) 

    #bin as key, Phylum as value
    bin_P = dfcontact1.set_index(['user_genome'])["Phylum"].to_dict()
    #bin as key, Species as value
    bin_S = dfcontact1.set_index(['user_genome'])['Species'].to_dict()
    #bin as key, POG as value
    bin_PS = dfcontact1.set_index(['user_genome'])['POG'].to_dict()
    #print(bin_PS)
    #Class + Species_name
    dfcontact1["CS"] = dfcontact1.apply(lambda x: str(x["Class"]) + ";" + str(x["Species"]), axis = 1) 
    #bin as key, Order_Species as value
    bin_CS = dfcontact1.set_index(['user_genome'])['CS'].to_dict()
    #print(bin_CS)
    #print(dfcontact1['Order'])

    bin_PS1 = dfcontact1.set_index(['user_genome'])['POG'].to_dict()
    #print(bin_PS1)
    bin_CS1 = dfcontact1.set_index(['user_genome'])['Phylum_Class'].to_dict()
    #print(bin_CS1)
    bin_OS1 = dfcontact1.set_index(['user_genome'])['Phylum_Order'].to_dict()
    #print(bin_OS1)
    bin_FS1 = dfcontact1.set_index(['user_genome'])['Phylum_Family'].to_dict()
    #print(bin_FS1)
    bin_GS1 = dfcontact1.set_index(['user_genome'])['Phylum_Genus'].to_dict()
    #print(bin_GS1)
    bin_SS1 = dfcontact1.set_index(['user_genome'])['POG'].to_dict()
    # print(bin_SS1)

    #12.01.2022Thursday NO Chloroplast bins within the 330 MAGs!!!!!!
    df_Chloroplast = dfcontact1[dfcontact1['Order'].str.contains("Chloroplast")]
    bin_Chloroplast = df_Chloroplast['user_genome'].tolist()
    #print(bin_Chloroplast)
    #print(len(bin_Chloroplast))

    return df_col2, bin_P, bin_S,bin_PS,bin_CS,bin_PS1,bin_CS1,bin_OS1,bin_FS1,bin_GS1,bin_SS1,bin_Chloroplast,dct6
#a is the file - gtdbtk.ar53.bac120.summary.tsv resulted from "gtdbtk classify_wf"
a = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/classify/gtdbtk.ar53.bac120.summary.tsv"
df_col2, bin_P, bin_S,bin_PS,bin_CS,bin_PS1,bin_CS1,bin_OS1,bin_FS1,bin_GS1,bin_SS1,bin_Chloroplast,dct6 = bin_SPS(a) 



site_depth_order_dict = {"Omstrup":["Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8"], "Sillebotten":["Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"]}
site_sort_col_dict = {"Omstrup":"Oms33-D1", "Sillebotten":"Sib-D1"}
#The script is to sort the relative abundance value and write them into a new tsv file
def coverm_RA(site, lev, lev_dct, MAG_RA_total, MAG_RA_total_top, MAG_RA, MAG_RA_top, MAG_RA_site, MAG_RA_site1, MAG_RA_site_top, MAG_site, MAG_GTDB_site, a, b, k, l, m, n, o, q, df_col2, c, e, f, h):
    #Giving the column of unmapped bins a name - unmapped
    lev_dct["unmapped"]="Unmapped"
    #read the original MAG abundance table
    df=pd.read_csv(a, sep="\t", comment="#", header=0)#,engine='python')#https://stackoverflow.com/questions/60455074/python-Lindas-parsererror-error-could-pCSsibly-be-due-to-quotes-being-ignored
    # print("df", df)
    # print("df.shape", df.shape)
    #change column names from "..._1.fq.gz Relative Abundance (%)" to "Sillebotten"
    df = df.rename(columns=lambda x: x.replace('_1.fq.gz Relative Abundance (%)', ''))

    df.set_index('Genome', inplace = True) 
    df['Mean_abundance'] = df.mean(axis=1, numeric_only=True).round(2)
    df = df.sort_values(by=['Mean_abundance'], ascending=False)
    df = df.round(2)
    df = df.reset_index()

    #6_6_2024_Thursday to get the Mean_abundance for each MAG_id in the supplementary table
    dct5 = df.set_index(['Genome'])['Mean_abundance'].to_dict()
    # print("dct5", dct5)

    df = df.drop(["Mean_abundance"],axis=1)

    ######phylum name + species name
    df['PS'] = df['Genome'].map(lambda x: lev_dct[x] if x in lev_dct.keys() else x)  
    #print(df)
    #set the column - PS as the 1st column
    #df_PS: the column - "PS" of the dataframe - df
    df_PS = df.PS
    #first drop the column df
    df = df.drop('PS',axis=1)
    #then insert to the place you want
    df.insert(1,'PS',df_PS)
    
    #drop the rows - 'unmapped'
    df = df.drop(df[df['PS'].str.contains('Unmapped')].index)
    #rename all columns
    #"Taxa": original MAG bin id
    #'Genome': Cyanobacteria;_
    df.columns = ["Taxa", 'Genome', "Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8", "Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8"]
    #print(df['Genome'])

    #Relative abundance of phyla-species total
    dfp = df.copy()
    dfp['Omstrup'] = dfp[["Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8"]].mean(axis=1)
    dfp['Sillebotten'] = dfp[["Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"]].mean(axis=1)
    #lev_dct1, bin_FS1
    dfp[lev] = dfp["Taxa"].map(lambda x: lev_dct[x] if x in lev_dct.keys() else x)      
    
    dfp_copy = dfp.copy()
    dfp = dfp.drop(["Taxa", 'Genome', "Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8", "Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"],axis=1)
    dfp = dfp.groupby(lev).sum()
    # print("dfp", dfp)

    dfp = dfp.sort_values(by=['Omstrup'], ascending=False).round(2) 
    #print(dfp)
    dfp['max_val'] = dfp.max(axis=1)
    dfp0 = dfp.loc[dfp['max_val']>0]
    dfp0 = dfp0.drop(["max_val"],axis=1)
    dfp0 = dfp0.reset_index()
    dfp0T = dfp0.T
    dfp0T.to_csv(MAG_RA_total, sep='\t', index=True, header=False)
    dfp1 = dfp.loc[dfp['max_val']>=0.1]
    dfp1 = dfp1.drop(["max_val"],axis=1)
    dfp1 = dfp1.reset_index()
    dfp1T = dfp1.T 
    #print(dfp1T) 
    #print(dff1.shape)
    dfp1T.to_csv(MAG_RA_total_top, sep='\t', index=True, header=False)

    #Relative abundance of phyla-species (total/>=0.1%) across eight depths in Omstrup and Sillebotten
    dfp_omssib = df.copy()   
    dfp_omssib = dfp_omssib.drop(['Genome'],axis=1)
    dfp_omssib[lev] = dfp_omssib["Taxa"].map(lambda x: lev_dct[x] if x in lev_dct.keys() else x)      
    dfp_omssib = dfp_omssib.groupby(lev).sum()
    depth_order = ["Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8", "Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"]
    dfp_omssib = dfp_omssib[depth_order]
    dfp_omssib = dfp_omssib.sort_values(by=['Oms33-D1'], ascending=False).round(2) 
    dfp_omssib['max_val'] = dfp_omssib.max(axis=1)
    dfp_omssib0 = dfp_omssib.loc[dfp_omssib['max_val']>0]
    dfp_omssib0 = dfp_omssib0.drop(["max_val"],axis=1)
    dfp_omssib0 = dfp_omssib0.reset_index()
    dfp_omssib0T = dfp_omssib0.T  
    dfp_omssib0T.to_csv(MAG_RA, sep='\t', index=True, header=False)
    dfp_omssib1 = dfp_omssib.loc[dfp_omssib['max_val']>=0.1]
    dfp_omssib1 = dfp_omssib1.drop(["max_val"],axis=1)
    dfp_omssib1 = dfp_omssib1.reset_index()
    dfp_omssib1T = dfp_omssib1.T 
    dfp_omssib1T.to_csv(MAG_RA_top, sep='\t',index=True,header=False)

    #Relative abundance of phyla-species (total/>=0.1%) across eight depths in Omstrup or in Sillebotten
    depth_order = site_depth_order_dict[site]
    depth_order1 = depth_order.copy()
    depth_order1.insert(0,"Taxa")
    sort_col = site_sort_col_dict[site]
    # print("lev", lev)
    # print("site", site)
    # print("df.columns", df.columns) 
    # print("depth_order", depth_order)
    # print("depth_order1", depth_order1)    
    # print("df.shape", df.shape)  
    df_site = df[depth_order1]
    # df_site.set_index("Taxa", inplace = True) 
    # print("df_site.shape", df_site.shape)
    df_site['Mean_abundance']= df_site.mean(axis=1, numeric_only=True).round(2)
    df_site = df_site[df_site['Mean_abundance']>0]
    df_site = df_site.sort_values(by=["Mean_abundance"], ascending=False).round(2)     
    # print("site", site)    
    # print("df_site", df_site)
    # print("df_site.columns", df_site.columns)
    # print("df_site.shape", df_site.shape)
    df_site["Taxa"].to_csv(MAG_site, sep='\t',index=False,header=False)
    site_taxa = df_site["Taxa"].tolist()
    df_col2 = df_col2[df_col2["user_genome"].isin(site_taxa)]
    # print("df_col2", df_col2)
    # print("df_col2.shape", df_col2.shape)
    #change all "." to "_" for the names of all MAGs
    #binny_I01R01.000048_C91_P97_Synechococcus -> binny_I01R01.000048_C91_P97
    df_col2["user_genome"] = df_col2["user_genome"].map(lambda x: "_".join((x.split("_")[:-1])) if x.startswith("binny_") else x)
    # print("df_col2_user_genome", df_col2["user_genome"])
    df_col2.to_csv(MAG_GTDB_site, sep='\t',index=False,header=True)

    dfp_site = df.copy()   
    dfp_site = dfp_site.drop(['Genome'],axis=1)
    dfp_site[lev] = dfp_site["Taxa"].map(lambda x: lev_dct[x] if x in lev_dct.keys() else x)      
    dfp_site = dfp_site.groupby(lev).sum()
    dfp_site = dfp_site[depth_order]
    # print("dfp_site.shape", dfp_site.shape)
    dfp_site = dfp_site.sort_values(by=[sort_col], ascending=False).round(2) 
    dfp_site['max_val'] = dfp_site.max(axis=1)
    # dfp_site0 = dfp_site.loc[dfp_site['max_val']>=0]
    dfp_site0 = dfp_site[dfp_site['max_val']>=0]
    dfp_site0 = dfp_site0.drop(["max_val"],axis=1)
    # print("dfp_site0.shape", dfp_site0.shape)
    dfp_site0 = dfp_site0.reset_index()
    # print(dfp_site0, "dfp_site0")

    dfp_site0_copy = dfp_site0.copy()
    dfp_site0_copy["Phylum_name"] = dfp_site0_copy[lev].map(lambda x: (x.split(";"))[0])      
    # print("dfp_site0_copy['Phylum_name']", dfp_site0_copy["Phylum_name"])
    dfp_site0_copy = dfp_site0_copy.drop([lev],axis=1)  
    dfp_site0_copy = dfp_site0_copy.groupby("Phylum_name").sum().round(2) 
    dfp_site0_copy = dfp_site0_copy[depth_order] 

    dfp_site0_copyT = dfp_site0_copy.T 
    # print("dfp_site0_copyT", dfp_site0_copyT)
    dfp_site0_copyT.to_csv(MAG_RA_site1, sep='\t', index=True, header=True)

    dfp_site0T = dfp_site0.T  
    # print(dfp_site0T, "dfp_site0T")
    dfp_site0T.to_csv(MAG_RA_site, sep='\t', index=True, header=False)
    # dfp_site1 = dfp_site.loc[dfp_site['max_val']>=0.1]
    dfp_site1 = dfp_site[dfp_site['max_val']>=0.1]
    dfp_site1 = dfp_site1.drop(["max_val"],axis=1)
    # print("dfp_site1.shape", dfp_site1.shape)
    dfp_site1 = dfp_site1.reset_index()
    dfp_site1T = dfp_site1.T 
    dfp_site1T.to_csv(MAG_RA_site_top, sep='\t',index=True,header=False)

    df1 = df.assign(freq = df.groupby("Genome")["Genome"].transform("count")).sort_values(by = ["freq", "Genome"],ascending = [False, False]).loc[:, ["Genome"]]
    # print("df1", df1)
    df1_index = list(df1.index)
    # print("df1_index", df1_index)    
    df = df.reindex(df1_index)
    # print("df", df)      
    order = df1["Genome"].value_counts().reset_index() 
    # print("order", order)
    freq_lst = order["Genome"].tolist()   
    # print("freq_lst", freq_lst)
    #make one index list for the input list---freq_lst, but the first index is 1 instead of 0
    index_lst=list(chain(*[list(range(1, x + 1)) for x in freq_lst]))
    # print("index_lst", index_lst)    
    df["Genome_order"] = index_lst
    df["MAG_taxa"] = df.apply(lambda x: x["Genome"] + "" + str(x["Genome_order"]) if (x["Genome"]).endswith("_") else x["Genome"] + "_" + str(x["Genome_order"]), axis = 1) 
    # print("df_MAG_taxa", df["MAG_taxa"])

    #dct: "MAG_taxa" as key, "Genome" as value
    dct = df.set_index(['MAG_taxa'])['Genome'].to_dict()
    #dct1: "MAG_taxa" as key, "Genome_order" as value
    dct1 = df.set_index(['MAG_taxa'])['Genome_order'].to_dict()
    #dct2: "Taxa" as key, "MAG_taxa" as value
    dct2 = df.set_index(['Taxa'])['MAG_taxa'].to_dict()
    # print("df", df)
 
    #6_6_2024_Thursday to get the MAG_identifier for each MAG_id in the supplementary table
    dct4 = df.set_index(['Taxa'])['MAG_taxa'].to_dict()
    # print("dct4", dct4)

    #to check the MAG_taxa of the most abundant MAG
    df_site["MAG_taxa"] = df_site.apply(lambda x: dct2[x["Taxa"]], axis = 1) 
    # print("site", site)
    # print("df_site_col2", df_site[['MAG_taxa', 'Mean_abundance']])
    # print("df_site.columns", df_site.columns)
    # print("df_site.shape", df_site.shape)

    #For the relative abundance of each MAG in two sites across eight depths, try to put MAGs belong to same phyla together
    #sort the 330 rows according to the frequency of each phylum
    df_copy = df.copy()
    df_copy["Phylum"] = df_copy["MAG_taxa"].map(lambda x: x.split(";")[0]) 
    # print("df_copy_Phylum", df_copy["Phylum"])
    # print("df_copy_Phylum_list", df_copy["Phylum"].tolist())
    Phylum_freq = Counter(df_copy["Phylum"].tolist())
    # print("Phylum_freq", Phylum_freq)
    df_copy1 = df_copy.assign(freq = df_copy.groupby("Phylum")["Phylum"].transform("count")).sort_values(by = ["freq", "Phylum"],ascending = [False, False]).loc[:, ["Phylum"]]
    # print("df_copy1", df_copy1)
    df_copy1_index = list(df_copy1.index)
    # print("df_copy1_index", df_copy1_index)    
    df_copy = df_copy.reindex(df_copy1_index)
    # print("df_copy_Phylum",df_copy["Phylum"])

    #4_6_2024 MAG submission to NCBI
    df_copy["derived_from"] = df_copy['Taxa'].map(lambda x: biosample_oms_str if x in MAGlist_oms else biosample_sib_str)      
    df_copy_MIMAGsediment_6_0 = df_copy[['Taxa',"MAG_taxa","derived_from"]]
    df_copy_MIMAGsediment_6_0.to_csv(h, sep='\t', index=False, header=True)

    df_copy = df_copy[["MAG_taxa", "Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8", "Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"]]  
    # print("df_copy", df_copy)
    df_copy.to_csv(c, sep='\t', index=False, header=True)

    ######phylum name + species name
    # df['MAG_taxa'] = df['MAG_taxa'].map(lambda x: x if dct[x].endswith("_") else x.replace(str(dct1[x]), ''))  
    #print(df["MAG_taxa"])

    ###df2=df.drop(labels=["Taxa",'Genome_order'],axis=1)
    df2=df.drop(labels=['Genome_order'],axis=1)
    #dct: "Genome" as key, "MAG_taxa" as value
    dct2 = df2.set_index(['Genome'])['MAG_taxa'].to_dict()
    #print(df2['MAG_taxa'])
    df2.set_index('MAG_taxa', inplace = True) 
    # #numeric_only=True: only calculate the numeric value columns, exclude columns - 'CS', 'Genome'
    df2['Mean_abundance']= df2.mean(axis=1, numeric_only=True).round(2)
    df2 = df2.sort_values(by=['Mean_abundance'], ascending=False)
    df2 = df2.round(2)
    #print(df2)
    df2 = df2.reset_index()
    df2["MAG_quality"] = df2["Taxa"].map(lambda x: MAG_quality_dict1[x]) 
    df2['MAG_taxa'] = df2.apply(lambda x: x["MAG_taxa"] + "(" + x["MAG_quality"] + ")", axis = 1) 
    # #print(df["MAG_taxa"])

    #make a dict using Taxa as key and MAG_taxa as value
    dct3 = df2.set_index(['MAG_taxa'])['Taxa'].to_dict()

    df2_copy = df2.copy()
    # # #drop the columns - 'Genome',"Mean_abundance"
    df2 = df2.drop(['Genome', "MAG_quality", "Taxa", "Mean_abundance"],axis=1)    
    #print(df2.shape)
    #print(df2)
    df2.to_csv(b, sep='\t',index=False,header=True)

    #check the species name of each MAG
    df2_copy_HQ = df2_copy[df2_copy["MAG_taxa"].str.contains("(HQ)")]
    df2_copy_HQ["Species"] = df2_copy_HQ.apply(lambda x: bin_S[x["Taxa"]],axis=1)
    #print("df2_copy_HQ[Species]", df2_copy_HQ["Species"])
    # print("df2_copy_HQ", df2_copy_HQ)
    # print("df2_copy_HQ.columns", df2_copy_HQ.columns)
    df_dataset_gradient_template1 = df2_copy_HQ[["Taxa", "Species"]]
    # print("df_dataset_gradient_template1", df_dataset_gradient_template1)
    df_dataset_gradient_template1.to_csv(p, sep='\t',index=False,header=True)    

    #to check how many HQ MAG from Sillebotten and Ormstrup, respectively
    df2_HQ = df2[df2["MAG_taxa"].str.contains("(HQ)")]
    #check the mean abundance of all HQ MAGs from Sillebotten and Ormstrup
    df2_HQ_copy = df2_HQ.copy() 
    df2_HQ_copy.set_index('MAG_taxa', inplace = True) 
    df2_HQ_copy['row_sum']=df2_HQ_copy.apply(lambda x: x.sum(),axis=1) 
    df2_HQ_copy.loc['col_sum'] = df2_HQ_copy.apply(lambda x: x.sum(),axis=0)
    # print("df2_HQ_copy", df2_HQ_copy)
    # print("df2_HQ_copy_row_sum", df2_HQ_copy['row_sum'].to_list())

    #check the mean relative abundance of 41 HQ MAGs in the two sites
    df2_HQ["Sib_mean"] = df2_HQ[["Sib-D1", "Sib-D2","Sib-D3", "Sib-D4","Sib-D5", "Sib-D6","Sib-D7", "Sib-D8"]].mean(axis=1)    
    df2_HQ["Oms_mean"] = df2_HQ[["Oms33-D1", "Oms33-D2","Oms33-D3", "Oms33-D4","Oms33-D5", "Oms33-D6","Oms33-D7", "Oms33-D8"]].mean(axis=1)    
    #check how many HQ MAGs only from Sillebotten
    df2_HQ_Sib = df2_HQ.loc[(df2_HQ["Sib_mean"]>0) & (df2_HQ["Oms_mean"]==0)]
    # print("df2_HQ_Sib.index", df2_HQ_Sib.index)
    # print("df2_HQ_Sib", df2_HQ_Sib)
    df2_HQ_Sib_id_list = []
    for n in list(df2_HQ_Sib["MAG_taxa"]):
        n1 = dct3[n]
        df2_HQ_Sib_id_list.append(n1)
    with open(f, 'w', newline='') as f_output:
        tsv_output = csv.writer(f_output, delimiter='\n')
        tsv_output.writerow(df2_HQ_Sib_id_list)
    # print("df2_HQ_Sib.shape", df2_HQ_Sib.shape)
    #check how many HQ MAGs only from Ormstrup
    df2_HQ_Oms = df2_HQ.loc[(df2_HQ["Sib_mean"]==0) & (df2_HQ["Oms_mean"]>0)]
    # print("df2_HQ_Oms.index", df2_HQ_Oms.index)  
    # print("df2_HQ_Oms", df2_HQ_Oms)
    df2_HQ_Oms_id_list = []
    for n in list(df2_HQ_Oms["MAG_taxa"]):
        n1 = dct3[n]
        df2_HQ_Oms_id_list.append(n1)
    with open(e, 'w', newline='') as f_output:
        tsv_output = csv.writer(f_output, delimiter='\n')
        tsv_output.writerow(df2_HQ_Oms_id_list)
    # print("df2_HQ_Oms.shape", df2_HQ_Oms.shape)
    #check how many HQ MAGs can be found in the two sites
    df2_HQ_SibOms = df2_HQ.loc[(df2_HQ["Sib_mean"]>0) & (df2_HQ["Oms_mean"]>0)]
    # print("df2_HQ_SibOms.shape", df2_HQ_SibOms.shape)
    # df2_HQ_Sib (17, 19)
    # df2_HQ_Oms (24, 19)
    # df2_HQ_SibOms (0, 19)



    #to add two lines for the lefse analysis
    #!!!!!!!!!!
    df2.columns = ["Class", "Sib_D1", "Sib_D2", "Sib_D3", "Sib_D4", "Sib_D5", "Sib_D6", "Sib_D7", "Sib_D8", "Oms_D1", "Oms_D2", "Oms_D3", "Oms_D4", "Oms_D5", "Oms_D6", "Oms_D7", "Oms_D8"]
    #新建一个df_insert
    #!!!!!!!!!!
    df_insert = pd.DataFrame(["Sample_ID", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"]).T
    # 修改df2的column和df的一致
    df_insert.columns = df2.columns
    # 把两个dataframe合并，需要设置 ignore_index=True
    df2 = pd.concat([df_insert,df2], axis=0 ,ignore_index=True) #参数axis=0表示上下合并，1表示左右合并，ignore_index=True表示忽略原来的索引
    #新建一个df_insert
    #!!!!!!!!!!
    df_insert1 = pd.DataFrame(["Subclass", "Oms", "Oms", "Oms", "Oms", "Oms", "Oms", "Oms", "Oms", "Sib", "Sib", "Sib", "Sib", "Sib", "Sib", "Sib", "Sib"]).T
    # 修改df2的column和df的一致
    df_insert1.columns = df2.columns
    # 把两个dataframe合并，需要设置 ignore_index=True
    df2 = pd.concat([df_insert1,df2], axis=0 ,ignore_index=True) #参数axis=0表示上下合并，1表示左右合并，ignore_index=True表示忽略原来的索引
    ###!!!
    df2 = df2.fillna(0)
    df2.to_csv(m, sep='\t',index=False,header=True)

    #tree: /home/projects/env_10000/people/binson/MTB/gtdbtk/de_novo_wf/species_omstrup_sillebotten_sediment_norefinem/infer/labelremoved_gtdbtk.ar53.unrooted.bac120.decorated.nwk
    #to generate the colors_styles_template for the tree
    df_copy = df.copy()    
    # print("df_copy", df_copy)
    # print("df_copy.shape", df_copy.shape)
    # print("df_copy.columns", df_copy.columns)
    df_copy["Phylum"] = df_copy['MAG_taxa'].map(lambda x: (x.split(";"))[0])  
    # print("df_copy_Phylum", df_copy["Phylum"])
    label_list = df_copy["Phylum"].unique().tolist()
    # print("label_list", label_list)    
    # print("label_list_len", len(label_list))
    color_phyla39 = [
                     "#03045e", "#0077b6", "#00b4d8", "#90e0ef", "#caf0f8", 
                     "#f70000", "#ff3333", "#ff5a5a", "#ff8282", "#ffd0d0", 
                     "#1b4332", "#40916c", "#74c69d", "#b7e4c7", "#d8f3dc", 
                     "#c9184a", "#ff4d6d", "#ff758f", "#ff8fa3", "#fff0f3", 
                     "#ffef3f", "#ffff3f", "#efff3f", "#dfff3f", "#cfff3f", 
                     "#595959", "#7f7f7f", "#a5a5a5", "#cccccc", "#f2f2f2", 
                     "#5a189a", "#7b2cbf", "#9d4edd", "#c77dff", "#e0aaff", 
                     "#774936", "#8a5a44", "#9d6b53", "#c38e70"]
    taxa_color_dict = dict(zip(label_list, color_phyla39))
    # print("taxa_color_dict", taxa_color_dict)
    # print("taxa_color_dict.keys", list(taxa_color_dict.keys()))
    # print("taxa_color_dict.values", list(taxa_color_dict.values()))
    LEGEND_SHAPE = [1]
    LEGEND_SHAPES = [val for val in LEGEND_SHAPE for i in range(len(list(taxa_color_dict.keys())))]
    # print("LEGEND_SHAPES", LEGEND_SHAPES)

    df_copy["Phy_color"] = df_copy["Phylum"].map(lambda x: taxa_color_dict[x] if x in taxa_color_dict.keys() else x)        
    df_copy["range"] = "range"
    df_copy_colors_styles_template = df_copy[["Taxa", "range", "Phy_color", "Phylum"]]
    # print("df_copy_colors_styles_template", df_copy_colors_styles_template)
    df_copy_colors_styles_template.to_csv(k, sep='\t',index=False,header=True)

    #to generate the labels_template for the tree
    df_copy_labels_template = df_copy[["Taxa","Phylum"]]
    #print(df_copy_labels_template)
    df_copy_labels_template.to_csv(l, sep='\t',index=False,header=True)

    #to generate the labels_template1 for the tree
    df_copy_labels_template1 = df_copy[["Taxa",'MAG_taxa']]
    # print(df_copy_labels_template1)
    df_copy_labels_template1.to_csv(q, sep='\t',index=False,header=True)

    #to generate the dataset_color_strip_template for the tree
    df_dataset_color_strip_template = df_copy[["Taxa", "Phy_color", "Phylum"]]
    # print("df_dataset_color_strip_template", df_dataset_color_strip_template)
    df_dataset_color_strip_template.to_csv(n, sep='\t',index=False,header=True)

    #to generate the dataset_gradient_template for the tree
    df_copy['Omstrup'] = df_copy[["Oms33-D1", "Oms33-D2", "Oms33-D3", "Oms33-D4", "Oms33-D5", "Oms33-D6", "Oms33-D7", "Oms33-D8"]].mean(axis=1)
    df_copy['Sillebotten'] = df_copy[["Sib-D1", "Sib-D2", "Sib-D3", "Sib-D4", "Sib-D5", "Sib-D6", "Sib-D7", "Sib-D8"]].mean(axis=1)
    df_copy["bin_shape"] = df_copy.apply(lambda x: "oms_only" if x["Omstrup"] > 0 and x["Sillebotten"] == 0 else ("sib_only" if x["Sillebotten"] > 0 and x["Omstrup"] == 0 else "omssib"), axis=1)
    # print(df_copy["bin_shape"])
    df_copy["bin_color"] = df_copy.apply(lambda x: 0 if x["bin_shape"] == "oms_only" else (1 if x["bin_shape"] == "sib_only" else 2), axis=1)
    df_dataset_gradient_template = df_copy[["Taxa", "bin_color"]]
    df_dataset_gradient_template.to_csv(o, sep='\t',index=False,header=True) 

    return dct4, dct5, df2
#the gtdbtk.ar53.bac120.summary from coverm_MTB_sillebotten_sediment_norefinem
a = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/relative_abundance.tsv"
c = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/relative_abundance_sorted.tsv"
g = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/relative_abundance_sorted.tsv"
e = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/oms_HQ.tsv"
f = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/sib_HQ.tsv"
k = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/colors_styles_template.tsv"
l = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/labels_template.tsv"
n = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/dataset_color_strip_template.tsv"
o = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/dataset_gradient_template.tsv"
#p is the species name of each MAG
p = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/dataset_gradient_template1.tsv"
q = "/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_omstrup_sillebotten_sediment_norefinem/labels_template1.tsv"

# binlev_dct = {"Phylum":bin_PS1, "Class":bin_CS1, "Order":bin_OS1, "Family":bin_FS1, "Genus":bin_GS1, "Species":bin_SS1}
# levels = ["Phylum", "Class", "Order", "Family", "Genus", "Species"]
binlev_dct = {"Phylum":bin_PS1, "Species":bin_SS1}
levels = ["Phylum", "Species"]
sites = ["Sillebotten", "Omstrup"]
for site in sites:
    for lev in levels:
        lev_dct = binlev_dct[lev]
        MAG_RA_total = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_oms_sib_{lev}_total.tsv"
        MAG_RA_total_top = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_oms_sib_{lev}_total_top.tsv"
        MAG_RA = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_oms_sib_{lev}.tsv"
        MAG_RA_top = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_oms_sib_{lev}_top.tsv"
        MAG_RA_site = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_{site}_{lev}.tsv"
        MAG_RA_site1 = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_{site}_{lev}_1.tsv"

        MAG_RA_site_top = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_abundance_{site}_{lev}_top.tsv"
        #MAG_site for the MetaCHIP
        MAG_site = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_{site}_{lev}.tsv"
        MAG_GTDB_site = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MAG_GTDB_{site}.tsv"
        
        b = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/relative_abundance_sorted_sillebotten_sediment_norefinem_{lev}.tsv"
        m = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/relative_abundance_sorted_sillebotten_sediment_norefinem_{lev}_lefse.tsv"

        h = f"/home/projects/env_10000/people/binson/MTB/coverm/coverm_oms_sib_sediment_norefinem/MIMAG_sediment_{site}_{lev}.tsv"

        dct4, dct5, df2 = coverm_RA(site, lev, lev_dct, MAG_RA_total, MAG_RA_total_top, MAG_RA, MAG_RA_top, MAG_RA_site, MAG_RA_site1, MAG_RA_site_top, MAG_site, MAG_GTDB_site, a, b, k, l, m, n, o, q, df_col2, c, e, f, h)


        #6_6_2024_Thursday to build a supplementart table - MAG_ID,MAG_identifier,gtdbtk_classification,Mean_abundance,......
        maginfo = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/data_tables/Widb.csv"
        supplementary_table = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/data_tables/Table_S4.tsv"
        MAG_cont_comp = "/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_omstrup_sillebotten_sediment_norefinem/95/data_tables/MAG_cont_comp.tsv"
        MAGlist,MAG_quality_dict,MAG_quality_dict1,df_out = MAG_quality(maginfo,MAG_cont_comp)  
        df_out["MAG_identifier"] = df_out.apply(lambda x: dct4[x["MAG"]],axis=1)
        df_out["gtdbtk_classification"] = df_out.apply(lambda x: dct6[x["MAG"]],axis=1)
        df_out["mean_abundance"] = df_out.apply(lambda x: dct5[x["MAG"]],axis=1)
        df_out = df_out[["genome", "MAG_identifier", "gtdbtk_classification", "mean_abundance", "score", "completeness", "contamination", "strain_heterogeneity", "size", "N50", "cluster", "taxonomy", "tax_confidence", "cluster_members", "closest_cluster_member", "furthest_cluster_member", "completeness_metric", "contamination_metric"]]
        df_out.to_csv(supplementary_table, sep = "\t",index=False,header=True)
        # print("df_out", df_out)
        # print("df_out.shape", df_out.shape)
# module load tools computerome_utils/2.0
# module load anaconda3/2021.11
# python /home/projects/env_10000/people/binson/scripts/MTBscripts/species_omstrup_sillebotten_norefinem_bin_annotation_coverm.py
