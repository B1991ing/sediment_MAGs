#!usr/bin/python
from xml.etree.ElementTree import TreeBuilder
import pandas as pd
from pandas import Series,DataFrame
import os, re, csv
from itertools import chain

#MAG_quality, mam_domain
#To make the MAG_id has the same annotation order as the script - 
def MAG_quality(b):
    df=pd.read_csv(b,sep=",",header=0,engine='python')#,engine='python')
    df["MAG"] = df.apply(lambda x: x['genome'][:-4], axis = 1)
    #print(df['MAG'])
    #df["MAG_quality"] = df.apply(lambda x: x['completeness'], axis = 1) 
    df.loc[((df.completeness >= 50) & (90 > df.completeness) & (df.contamination <= 5)), 'MAG_quality'] = 'MQ'
    df.loc[((df.completeness > 90) & (df.contamination <= 5)), 'MAG_quality'] = 'HQ'
    MAG_quality_dict = df.set_index(['MAG'])['MAG_quality'].to_dict()
    #print(MAG_quality_dict)
    return MAG_quality_dict
maginfo ="/home/projects/env_10000/people/binson/MTB/drep/drep_vamb_binny_b3b_marinelake_norefinem/95/data_tables/Widb.csv"
MAG_quality_dict = MAG_quality(maginfo)  

def mam_domain(a):
    df_one_total = pd.DataFrame([], columns = ['qseqid', 'sseqid', 'qlen', 'slen', 'qstart', 'qend', 'qseq', 'sseq', 'length', 'pident', 'evalue', 'bitscore', "contig_gene", 'MAG_id', 'mam_id'])
    MAG_id_list = []  
    MAG_id_list1 = []
    MAG_mam_dict = {}
    MAG_contig_dict = {}
    for root, dirs, files in os.walk(a):
        for name in files:
            if name.endswith(".dmnd.out"):
                fileroot = "/".join((root, name))
                split_fileroot = fileroot.split("/")
                MAG_id = "_".join((split_fileroot[-1]).split("_")[:-2])
                if MAG_id not in MAG_id_list:
                    MAG_id_list.append(MAG_id)          
    print(MAG_id_list)
    return MAG_id_list
magfolder = "/home/projects/env_10000/people/binson/MTB/MTB_MAG_identification/species_marinelake_norefinem_prodigal_diamond_e40id30/"
MAG_id_list = mam_domain(magfolder)
#python /home/projects/env_10000/people/binson/scripts/MTBscripts/marinelake_norefinem_mam_domain_selection_diamond.py
#print(MAG_id_list)

#delete three strings at the beginning
def taxa_name(dfcontact1, taxa, replace_str):
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a[3:] if len(a)>3 else a)
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a.replace(replace_str, '_'))
    dfcontact1[taxa] = dfcontact1[taxa].map(lambda a : a.replace(' ', '_'))
    return dfcontact1[taxa]

#The function - tsv_to_profile is to make two dicts - bin_taxa_dict and bin_Phylum_Species_dict
def bin_SPS(a):
    df=pd.read_csv(a,sep="\t",comment="#",header=0)
    if a == "/home/projects/env_10000/people/binson/MTB/gtdbtk/MTB38_name.txt":
        #df["user_genome"] = df['user_genome'].map(lambda x: "Uzun_" + x) 
        MAG_source = "Uzun" 
    elif a == "/home/projects/env_10000/people/binson/MTB/gtdbtk/MTB168_name.txt":
        #df["user_genome"] = df['user_genome'].map(lambda x: "Lin_" + x)  
        MAG_source = "Lin" 
    else:
        #df["user_genome"] = df['user_genome'].map(lambda x: "Bing_" + x)  
        MAG_source = "Bing" 

    df1 = pd.DataFrame(df['classification'].str.split(';').tolist(), columns=['Domain', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species'])
    #print(df)
    df2 = df1[['Domain', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species']]
    dfcontact = pd.concat([df["user_genome"],df2], axis=1)
    #print(dfcontact)

    dfcontact1 = dfcontact.copy()
    dfcontact1['Phylum'] = dfcontact1['Phylum'].map(lambda a : a[3:])
    dfcontact1['Class'] = taxa_name(dfcontact1, 'Class', 'c__')
    dfcontact1['Family'] = taxa_name(dfcontact1, 'Family', 'f__')
    dfcontact1['Order'] = taxa_name(dfcontact1, 'Order', 'o__')
    dfcontact1['Genus'] = taxa_name(dfcontact1, 'Genus', 'g__')
    dfcontact1['Species'] = taxa_name(dfcontact1, 'Species', 's__')

    #Phylum_name + Species_name
    dfcontact1["Phylum_Species"] = dfcontact1.apply(lambda x: x["Phylum"] + "_" + str(x["Species"]), axis = 1) 
    #bin as key, Species as value
    bin_S = dfcontact1.set_index(['user_genome'])['Species'].to_dict()
    #bin as key, Phylum_Species as value
    bin_PS = dfcontact1.set_index(['user_genome'])['Phylum_Species'].to_dict()
    #print(bin_PS)
    #Class + Species_name
    #dfcontact1["CS"] = dfcontact1.apply(lambda x:str(x["Class"]) + ";" + str(x["Species"]), axis = 1) 
    dfcontact1["CS"] = dfcontact1.apply(lambda x: MAG_source + ";" + str(x["Class"]) + ";" + str(x["Species"]), axis = 1) 
    #bin as key, Order_Species as value
    bin_CS = dfcontact1.set_index(['user_genome'])['CS'].to_dict()
    #print(bin_CS)
    #print(dfcontact1['Order'])
    return bin_S,bin_PS,bin_CS
#a is the file - gtdbtk.bac120.summary.tsv resulted from "gtdbtk classify_wf"
a ="/home/projects/env_10000/people/binson/MTB/gtdbtk/classify_wf/species_marinelake_norefinem/classify/gtdbtk.ar53.bac120.summary.tsv"
bin_S,bin_PS,bin_CS = bin_SPS(a) 
b ="/home/projects/env_10000/people/binson/MTB/gtdbtk/MTB38_name.txt"
bin_SU,bin_PSU,bin_CSU = bin_SPS(b)  
c ="/home/projects/env_10000/people/binson/MTB/gtdbtk/MTB168_name.txt"
bin_SP,bin_PSP,bin_CSP = bin_SPS(c)  
bin_CS.update(bin_CSU)
bin_CS.update(bin_CSP)
#print(bin_CS)

#The script is to select top 12 mCSt abundant MAGs according to the relative abundance value and write them into a tsv file
def coverm_RA(bin_CS, a, b):
    #Giving the column of unmapped bins a name - unmapped
    bin_CS["unmapped"]="Unmapped"
    #read the original MAG abundance table
    df=pd.read_csv(a, sep="\t", comment="#", header=0)#,engine='python')#https://stackoverflow.com/questions/60455074/python-Lindas-parsererror-error-could-pCSsibly-be-due-to-quotes-being-ignored
    #print(df)

    ######class name + species name
    df['CS'] = df['Genome'].map(lambda x: bin_CS[x] if x in bin_CS.keys() else x)  

    #print(df)
    #set the column - CS as the 1st column
    #df_CS: the column - "CS" of the dataframe - df
    df_CS = df.CS
    #first drop the column df
    df = df.drop('CS',axis=1)
    #then insert to the place you want
    df.insert(1,'CS',df_CS)

    #change column names from "25_1.fq.gz Relative Abundance (%)" to "Sillebotten"
    df = df.rename(columns=lambda x: x.replace('_1.fq.gz Relative Abundance (%)', ''))

    df['Fureso'] = df[['31', '32']].mean(axis=1)
    df['Omstrup5'] = df[['33', '34']].mean(axis=1)
    df['Omstrup33'] = df[['35', '36']].mean(axis=1)

    #drop the columns - 'Genome','31', '32','33', '34','35', '36'
    df = df.drop(['31', '32','33', '34','35', '36'],axis=1)

    #drop the rows - 'unmapped'
    df = df.drop(df[df['CS'].str.contains('Unmapped')].index)
    #rename all columns
    df.columns = ["Taxa", 'Genome', "Flensborg_Fjord", "Sillebotten", "Feddet", "Fureso", "Ormstrup5", "Ormstrup33"]
    #print(df["Taxa"])
    #print(df)



    df_bing = df.loc[df['Taxa'].isin(MAG_id_list)]
    #print(df_bing.shape)
    ######reorder the whole dataframe according to the MAG_id_list
    df_bing['Taxa'] = df_bing['Taxa'].astype('category')
    #print(df_bing['Taxa'])
    df_bing['Taxa'].cat.reorder_categories(MAG_id_list, inplace=True)
    #print(df_bing['Taxa'])
    df_bing.sort_values('Taxa', inplace=True)
    #print(df_bing)
    df_Lin_Uzun = df.drop(df.loc[df['Taxa'].isin(MAG_id_list)].index)
    #print(df_Lin_Uzun.shape) 
    df_bing_Lin_Uzun = pd.concat([df_Lin_Uzun,df_bing])
    df = df_bing_Lin_Uzun
    #print(df)     
    #print(df.shape) 



    df1 = df.assign(freq = df.groupby("Genome")["Genome"].transform("count")).sort_values(by = ["freq", "Genome"],ascending = [False, False]).loc[:, ["Genome"]]
    df1_index = list(df1.index)
    df = df.reindex(df1_index) 
    order = df1["Genome"].value_counts().reset_index() 
    freq_lst = order["Genome"].tolist()   

    #make one index list for the input list---freq_lst, but the first index is 1 instead of 0
    index_lst=list(chain(*[list(range(1, x + 1)) for x in freq_lst]))
    df["Genome_order"] = index_lst
    df["MAG_taxa"] = df.apply(lambda x: x["Genome"] + str(x["Genome_order"]), axis = 1) 
    #print(df["MAG_taxa"])

    #dct: "MAG_taxa" as key, "Genome" as value
    dct = df.set_index(['MAG_taxa'])['Genome'].to_dict()
    #dct1: "MAG_taxa" as key, "Genome_order" as value
    dct1 = df.set_index(['MAG_taxa'])['Genome_order'].to_dict()

    ######class name + species name
    df['MAG_taxa'] = df['MAG_taxa'].map(lambda x: x if dct[x].endswith("_") else x.replace(str(dct1[x]), ''))  
    #print(df["MAG_taxa"])

    binglist = ['lake_bin.14', 'lake_bin.3', 'binny_I01R01.000014_C91_P97_Desulfobacteraceae', 'binny_I07R05.000017_C70_P95_Spirochaetes', 'lake_bin.31', 'binny_I01R02.003304_C94_P94_Alphaproteobacteria', 'lake_bin.13', 'marine_bin.23']
    df_bing1 = df.loc[df['Taxa'].isin(binglist)]
    #select 9 MTB MAG from 63 Bing MAG
    df_Lin_Uzun1 = df.drop(df.loc[df['MAG_taxa'].str.contains('Bing;')].index)
    #print(df_Lin_Uzun1)
    print(df_Lin_Uzun1.shape)
    df_bing_Lin_Uzun1 = pd.concat([df_Lin_Uzun1,df_bing1])
    df = df_bing_Lin_Uzun1
    #print(df)
    #print(df.shape)

    df2=df.drop(labels=['Taxa','Genome_order'],axis=1)
    #dct: "Genome" as key, "MAG_taxa" as value
    dct2 = df2.set_index(['Genome'])['MAG_taxa'].to_dict()
    print(df2['MAG_taxa']) 
    df2.set_index('MAG_taxa', inplace = True) 

    # #the mean abundance value for each bin in 6 locations
    # #numeric_only=True: only calculate the numeric value columns, exclude columns - 'CS', 'Genome'
    df2['Mean_abundance']= df2.mean(axis=1, numeric_only=True).round(2)
    df2 = df2.sort_values(by=['Mean_abundance'], ascending=False)
    df2 = df2.round(2)
    # #drop the columns - 'Genome',"Mean_abundance"
    df2 = df2.drop(['Genome',"Mean_abundance"],axis=1)
    df2.to_csv(b, sep='\t',index=True,header=True)



    df2 = df2.loc[(df2!=0).any(1)]
    df2 = df2.reset_index()
    df_Lin = df2[df2['MAG_taxa'].str.contains("Lin;")]
    #print(df_Lin)    
    #print(df_Lin.shape)
    df_Uzun = df2[df2['MAG_taxa'].str.contains('Uzun;')]
    #print(df_Uzun)
    #print(df_Uzun.shape)
    df_Bing = df2[df2['MAG_taxa'].str.contains('Bing;')]
    print(df_Bing)    
    print(df_Bing.shape)
    # ['marine_bin.23', 'lake_bin.14', 'lake_bin.31', 'binny_I01R01.000014_C91_P97_Desulfobacteraceae', 'binny_I01R02.003304_C94_P94_Alphaproteobacteria', 'binny_I07R05.000017_C70_P95_Spirochaetes', 'lake_bin.13', 'lake_bin.3']
    df_contact = pd.concat([df_Lin,df_Uzun,df_Bing]) 
    #print(df_contact)    
    print(df_contact.shape) 
    df_contact.set_index('MAG_taxa', inplace = True)   
    df_contact.to_csv(b, sep='\t',index=True,header=True) 
    return df2
 
#the gtdbtk.bac120.summary from coverm_MTB_marinelake_Lin_Uzun
a = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_MTB_marinelake_Lin_Uzun/relative_abundance.tsv"
b = "/home/projects/env_10000/people/binson/MTB/coverm/coverm_MTB_marinelake_Lin_Uzun/relative_abundance_sorted_marinelakenorefinem_Lin_Uzun.tsv"
df2 = coverm_RA(bin_CS, a, b)
# module load tools computerome_utils/2.0
# module load anaconda3/2021.11
# python /home/projects/env_10000/people/binson/scripts/MTBscripts/species_marinelake_norefinem_bin_annotation_coverm_206MTB.py