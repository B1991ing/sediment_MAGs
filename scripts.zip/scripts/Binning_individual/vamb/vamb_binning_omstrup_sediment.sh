#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N vamb_binning_omstrup_sediment
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/vamb_binning_omstrup_sediment.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/vamb_binning_omstrup_sediment.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=30:fatnode
### Memory
#PBS -l mem=1500gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=168:00:00

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load miniconda3/4.12.0
module load vamb/3.0.6
module load samtools/1.14
module load minimap2/2.6
module load snakemake/6.0.4

#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=30:fatnode,mem=1500gb,walltime=168:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/vamb_binning_omstrup_sediment.sh
#/home/projects/env_10000/people/binson/MTB/errfiles/vamb_binning_omstrup_sediment.err
#/home/projects/env_10000/people/binson/MTB/logfiles/vamb_binning_omstrup_sediment.log
#14:47:00, jobid 36661122, 23.7.2022
configuration_file=/home/projects/env_10000/people/binson/MTB/binning/vamb_omstrup_sediment/config_omstrup_sediment.json
snakemake --jobs 30 --cores 30 --configfile ${configuration_file} --snakefile /services/tools/vamb/3.0.3b/vamb/workflow/vamb.snake.conda.py --latency-wait 120 

qstat -f -1 $PBS_JOBID