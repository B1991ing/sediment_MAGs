#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N rawbam_1_24
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/rawbam_1_24.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/rawbam_1_24.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=30:fatnode
### Memory
#PBS -l mem=600gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=72:00:00
###in the qsub script will cause running the job 9 times with not more than 4 actives jobs at any given time as default
#PBS -t 1-24

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load miniconda3/4.12.0
module load snakemake/7.8.2
module load samtools/1.14
module load bwa/0.7.17
module load sambamba/0.8.0 

#8:38:45 (jobid 36402549[1], 9.7.2022)
#16:47:45 (jobid 36402549[2], 9.7.2022)
#15:37:20 (jobid 36402549[3], 9.7.2022)
#12:19:02 (jobid 36402549[4], 9.7.2022)
#12:36:09 (jobid 36402549[5], 9.7.2022)
#13:29:12 (jobid 36402549[6], 9.7.2022)
#13:54:10 (jobid 36402549[7], 9.7.2022)
#14:07:31 (jobid 36402549[8], 9.7.2022)
#11:59:43 (jobid 36402549[9], 9.7.2022)
#6:48:01 (jobid 36402549[10], 9.7.2022)
#6:30:52 (jobid 36402549[11], 9.7.2022)
#5:52:22 (jobid 36402549[12], 9.7.2022)
#6:43:00 (jobid 36402549[13], 9.7.2022)
#6:20:57 (jobid 36402549[14], 9.7.2022)
#6:31:33 (jobid 36402549[15], 9.7.2022)
#6:40:02 (jobid 36402549[16], 9.7.2022)
#5:58:58 (jobid 36402549[17], 9.7.2022)
#6:23:40 (jobid 36402549[18], 9.7.2022)
#6:16:26 (jobid 36402549[19], 9.7.2022)
#6:21:28 (jobid 36402549[20], 9.7.2022)
#6:07:53 (jobid 36402549[21], 9.7.2022)
#4:41:07 (jobid 36402549[22], 9.7.2022)
#4:42:16 (jobid 36402549[23], 9.7.2022)
#6:13:11 (jobid 36402549[24], 9.7.2022)
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=30:fatnode,mem=600gb,walltime=72:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/rawbam_1_24.sh
#error file: /home/projects/env_10000/people/binson/MTB/errfiles/rawbam_1_24.err
#log file: /home/projects/env_10000/people/binson/MTB/logfiles/rawbam_1_24.log

spades_output=/home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/spades_output_${PBS_ARRAYID}/
contig=${spades_output}contigs.fasta
bwa index ${contig}

fastq_dir=/home/projects/env_10000/people/binson/MTB/F22FTSEUET0054_METuxcM/Clean/${PBS_ARRAYID}/
cd ${fastq_dir} 
for f1 in ${PBS_ARRAYID}_1.fastq
do
    f2=${f1%%1.fastq}"2.fastq"
    bwa mem -t 30 -M ${contig} $f1 $f2 | samtools view -Sb - > ${spades_output}${f1%%_1.fastq}_raw.bam
done

# #get bams with unique mapped reads
cd ${spades_output}
for file in ${PBS_ARRAYID}_raw.bam
do
    sambamba view -t 30 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" $file -o ${file%%.bam}_unique.bam
done

# #sort the produced bam files
cd ${spades_output}
for file in ${PBS_ARRAYID}_raw_unique.bam
do
    samtools view -h $file | samtools view -Su -q30 - | samtools sort -O BAM -o ${file%%.bam}_sort.bam
    samtools index ${file%%.bam}_sort.bam   
done
