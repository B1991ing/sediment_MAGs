#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N binny_1_24
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/binny_1_24.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/binny_1_24.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=20:fatnode
### Memory
#PBS -l mem=1000gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=120:00:00
###in the qsub script will cause running the job 9 times with not more than 4 actives jobs at any given time as default
#PBS -t 1-24

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs
module load anaconda3/2021.11
module load miniconda3/4.12.0
module load snakemake/7.8.2

#1:00:56:04 (jobid 36417749[1], 10.7.2022)
#23:49:50 (jobid 36417749[2], 10.7.2022)
#1:04:00:45 (jobid 36417749[3], 10.7.2022)
#1:06:37:50 (jobid 36417749[4], 10.7.2022)
#1:05:40:41 (jobid 36417749[5], 10.7.2022)
#1:02:30:04 (jobid 36417749[6], 10.7.2022)
#23:27:19 (jobid 36417749[7], 10.7.2022)
#1:04:21:52 (jobid 36417749[8], 10.7.2022)
#1:03:11:42 (jobid 36417749[9], 10.7.2022)
#1:10:28:42 (jobid 36417749[10], 10.7.2022)
#1:12:51:53 (jobid 36417749[11], 10.7.2022)
#1:09:18:02 (jobid 36417749[12], 10.7.2022)
#1:01:09:08 (jobid 36417749[13], 10.7.2022)
#1:02:01:23 (jobid 36417749[14], 10.7.2022)
#1:11:02:54 (jobid 36417749[15], 10.7.2022)
#1:01:42:31 (jobid 36417749[16], 10.7.2022)
#1:02:45:34 (jobid 36417749[17], 10.7.2022)
#1:02:50:14 (jobid 36417749[18], 10.7.2022)
#1:08:59:13 (jobid 36417749[19], 10.7.2022)
#1:03:27:30 (jobid 36417749[20], 10.7.2022)
#1:01:35:18 (jobid 36417749[21], 10.7.2022)
#1:05:02:44 (jobid 36417749[22], 10.7.2022)
#1:03:08:13 (jobid 36417749[23], 10.7.2022)
#1:10:04:46 (jobid 36417749[24], 10.7.2022)

#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=20:fatnode,mem=1000gb,walltime=120:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/binny_1_24.sh
#error file: /home/projects/env_10000/people/binson/MTB/errfiles/binny_1_24.err
#log file: /home/projects/env_10000/people/binson/MTB/logfiles/binny_1_24.log
binny_dir=/home/projects/env_10000/people/binson/MTB/binning/binny_${PBS_ARRAYID}/
mv /home/projects/env_10000/people/binson/MTB/binning/config${PBS_ARRAYID}.yaml ${binny_dir}
configfile=${binny_dir}config${PBS_ARRAYID}.yaml
snakemake -c 20 -s /home/projects/env_10000/people/binson/binny/Snakefile --configfile ${configfile} --use-conda --conda-prefix /home/projects/env_10000/people/binson/binny/conda