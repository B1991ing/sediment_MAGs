#!/bin/sh
### Note: No commands may be executed until after the #PBS lines
### Account information
#PBS -W group_list=env_10000 -A env_10000
### Job name (comment out the next line to get the name of the script used as the job name)
#PBS -N metaSPAdes_assemble_1_8
### Output files (comment out the next 2 lines to get the job name used instead)
#PBS -e /home/projects/env_10000/people/binson/MTB/errfiles/metaSPAdes_assemble_1_8.err
#PBS -o /home/projects/env_10000/people/binson/MTB/logfiles/metaSPAdes_assemble_1_8.log
### Only send mail when job is aborted or terminates abnormally
#PBS -m n
### Number of nodes
#PBS -l nodes=1:ppn=40:fatnode
### Memory
#PBS -l mem=1500gb
### Requesting time - 1 hours - overwrites **long** queue setting
#PBS -l walltime=72:00:00
###in the qsub script will cause running the job 9 times with not more than 4 actives jobs at any given time as default
#PBS -t 1-8

# Go to the directory from where the job was submitted (initial directory is $HOME)
echo Working directory is $PBS_O_WORKDIR
cd $PBS_O_WORKDIR

### Here follows the user commands:
# Define number of processors
NPROCS=`wc -l < $PBS_NODEFILE`
echo This job has allocated $NPROCS nodes

# Load all required modules for the job
module load tools
module load ngs 
module load anaconda3/2021.11 #Anaconda3 2021.11 - Python 3.9 distribution for scientific computing
module load SPAdes/3.15.3

#2:10:17:42 (jobid 36148147[1], 25.6.2022)
#hours 22minutes 50seconds used (jobid 36148147[2], 25.6.2022)
#hours 47minutes 29seconds used (jobid 36148147[3], 25.6.2022)
#hours 15minutes 36seconds used (jobid 36148147[4], 25.6.2022)
#hours 47minutes 36seconds used (jobid 36148147[5], 25.6.2022)
#hours 4minutes 39seconds used (jobid 36148147[6], 25.6.2022)
#1:23:15:19 (jobid 36148147[7], 25.6.2022)
#hours 7minutes 46seconds used (jobid 36148147[8], 25.6.2022)

#modules: tools, ngs, anaconda3/2021.11, SPAdes/3.15.3
#Fatnode: qsub -W group_list=env_10000 -A env_10000 -l nodes=1:ppn=40:fatnode,mem=1500gb,walltime=72:00:00 /home/projects/env_10000/people/binson/scripts/MTBscripts/metaSPAdes_assemble_1_8.sh
#error file: /home/projects/env_10000/people/binson/MTB/errfiles/metaSPAdes_assemble_1_8.err
#log file: /home/projects/env_10000/people/binson/MTB/logfiles/metaSPAdes_assemble_1_8.log
# -m 120
mkdir -p /home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/spades_output_${PBS_ARRAYID}
#--memory
/services/tools/SPAdes/3.15.3/bin/spades.py --meta -k 21,33,55,77 --dataset /home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/my_data_set_${PBS_ARRAYID}.yaml -t 40 -m 1500 -o /home/projects/env_10000/people/binson/MTB/assemble/metaSPAdes_assemble/spades_output_${PBS_ARRAYID}

qstat -f -1 $PBS_JOBID